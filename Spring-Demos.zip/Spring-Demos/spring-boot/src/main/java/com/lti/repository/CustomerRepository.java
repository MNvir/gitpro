package com.lti.repository;

import java.util.List;

import com.lti.entity.Customer;

public interface CustomerRepository {

	void save(Customer customer);

	Customer fetchById(int id);

	List<Customer> fetchAll();

	int findByUsernamePassword(String email, String password);

}