package com.lti.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.Customer;

//@Component
@Repository
public class CustomerRepositoryImpl implements CustomerRepository{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void save(Customer  customer) {
		entityManager.merge(customer);
	}
	
	@Override
	public Customer fetchById(int id) {
		return entityManager.find(Customer.class, id);
	}
	
	@Override
	public List<Customer> fetchAll(){
		return entityManager.createNamedQuery("fetch-all").getResultList();
	}
	
	@Override
	public int findByUsernamePassword(String email, String password) {
		return (Integer)entityManager
				.createQuery("select c.id from Customer c where c.email =:em and c.password = :pass")
				.setParameter("em", email)
				.setParameter("pass", password)
				.getSingleResult();
	}
}
