package com.lti;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.CarPart;
import com.lti.component.CarPartsInventory;

public class App {

	public static void main(String[] args) {
	
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarPartsInventory cpInv = (CarPartsInventory) ctx.getBean("carParts4");
		
		CarPart cp = new CarPart();
		cp.setName("Windshield");
		cp.setCarModel("Maruti 800");
		cp.setPrice(1500);
		cp.setQuantity(5);
		
		cpInv.addNewPart(cp);
		
		List<CarPart> list = cpInv.getAvailableParts();
		
		for(CarPart c: list)
			System.out.println(c.getPartNo()+ " " + c.getName()+" "+ c.getCarModel());
	}
	
}
