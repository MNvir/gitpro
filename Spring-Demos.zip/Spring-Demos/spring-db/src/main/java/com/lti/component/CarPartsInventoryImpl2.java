package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("carParts2")
public class CarPartsInventoryImpl2 implements CarPartsInventory{

	@Autowired
	private DataSource dataSource;
	
	public void addNewPart(CarPart carPart) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = dataSource.getConnection();	
			
			stmt = conn.prepareStatement("INSERT INTO tbl_car_parts VALUES(?, ?, ?, ?, ?)");
			stmt.setInt(1, carPart.getPartNo());
			stmt.setString(2, carPart.getName());
			stmt.setString(3, carPart.getCarModel());
			stmt.setDouble(4, carPart.getPrice());
			stmt.setInt(5, carPart.getQuantity());
			stmt.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {conn.close();}catch(Exception e) {	
			}
		}
		
	}

	public List<CarPart> getAvailableParts() {
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs = null;
		try {
			conn = dataSource.getConnection();
			
			String sql="select * from tbl_car_parts";
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			
			List<CarPart> list = new ArrayList<CarPart>();
			
			while(rs.next()) {
				CarPart carPart = new CarPart();
				carPart.setPartNo(rs.getInt("part_no"));
				carPart.setName(rs.getString("name"));
				carPart.setCarModel(rs.getString("car_model"));
				carPart.setPrice(rs.getDouble("price"));
				carPart.setQuantity(rs.getInt("quantity"));
				
				list.add(carPart);
			}
				return list;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		finally {
			try {
				conn.close();
			}
			catch(Exception e) {
				
			}
		}
	}

}
