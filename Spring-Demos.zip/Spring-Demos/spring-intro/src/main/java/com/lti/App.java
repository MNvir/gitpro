package com.lti;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.Atm;
import com.lti.component.Calculator;
import com.lti.component.CurrencyConverter;
import com.lti.component.HelloWorld;
import com.lti.component.LoginService;
import com.lti.component.TextEditor;
import com.lti.exception.CurrencyConverterException;

public class App {

	public static void main(String[] args) {
		//Loading the IoC (Inversion of Control) container
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		//Accessing a bean
		HelloWorld h=(HelloWorld) ctx.getBean("hw");
		System.out.println(h.sayHello("Mani"));
		
		Calculator c = (Calculator) ctx.getBean("calc");
		System.out.println(c.add(10, 20));
		
		LoginService loginServ = (LoginService) ctx.getBean("loginServ");
		System.out.println(loginServ.isValid("mani", "123"));
		
		CurrencyConverter cc = (CurrencyConverter) ctx.getBean("cc");
		
		try {
			System.out.println(cc.convert("USD", "INR", 100));
		} catch (CurrencyConverterException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			System.out.println(cc.convert("YEN", "INR", 100));
		} catch (CurrencyConverterException e) {
			System.out.println(e.getMessage());
		}
		
		TextEditor te = (TextEditor) ctx.getBean("txtEdtr");
		te.load("Hello");
		
		Atm atm = (Atm) ctx.getBean("hfcAtm");
		System.out.println(atm.withdraw(100));
	}
}
