package com.lti.component;

public interface Atm {

	public String withdraw(int amount);
}
