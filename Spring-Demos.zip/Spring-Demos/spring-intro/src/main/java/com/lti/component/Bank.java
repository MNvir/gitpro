package com.lti.component;

public interface Bank {
	public String communicate(int atmId);
}
