package com.lti.component;

import com.lti.exception.CurrencyConverterException;

public interface CurrencyConverter {
	
	public double convert(String from, String to, double amount) throws CurrencyConverterException;
}
