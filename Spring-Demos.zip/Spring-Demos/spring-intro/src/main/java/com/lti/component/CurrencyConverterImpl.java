package com.lti.component;

import org.springframework.stereotype.Component;

import com.lti.exception.CurrencyConverterException;

@Component("cc")
public class CurrencyConverterImpl implements CurrencyConverter {

	public double convert(String from, String to, double amount) throws CurrencyConverterException{
		if(from.equals("USD") && to.equals("INR"))
			return amount*74.86;
		else if(from.equals("GBP") && to.equals("INR"))
			return amount*97.77;
		else
			throw new CurrencyConverterException("Conversion from "+ from +" to "+ to+ " is not implemented yet.");
	}
}
