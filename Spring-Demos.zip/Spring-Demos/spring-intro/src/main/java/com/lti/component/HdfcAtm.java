package com.lti.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("hfcAtm")
public class HdfcAtm implements Atm{
	@Autowired
	//if we have multiple classes implementing Bank interface we will use
	//@Qualifier("sbiBank")
	private Bank bank;
	
	public String withdraw(int amount) {
		System.out.println(bank.communicate(123));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return amount+ " withdrawn";
	}
	
	
}
