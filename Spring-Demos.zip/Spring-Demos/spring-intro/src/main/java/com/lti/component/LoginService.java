package com.lti.component;

import org.springframework.stereotype.Component;

@Component("loginServ")//alternative for <bean id="..." class="..." />
public class LoginService {
	
	public boolean isValid(String username, String password) {
		
		if(username.equals("mani")&& password.equals("123")) 
			return true;
		return false;
	}
}
