package com.lti.component;

import org.springframework.stereotype.Component;

@Component("bnk")
public class SbiBank implements Bank{

	public String communicate(int atmId) {
		return "The ATM: " +atmId+" is communicating with Bank....";
	}
	
}
