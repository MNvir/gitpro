package com.lti.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("txtEdtr")
public class TextEditor {
	
	@Autowired //Dependency Injection
	private SpellChecker sc;
	
	public void load(String document) {
		System.out.println("text editor loading " + document);
		
		//Tight coupling
		//SpellChecker sc = new SpellChecker();
		sc.checkSpellingMistakes(document);
		
	}
}
