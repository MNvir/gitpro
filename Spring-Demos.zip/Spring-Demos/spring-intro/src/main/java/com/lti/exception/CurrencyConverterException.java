package com.lti.exception;

public class CurrencyConverterException extends Exception {
	
	public CurrencyConverterException(String msg) {
		super(msg);
	}
}
