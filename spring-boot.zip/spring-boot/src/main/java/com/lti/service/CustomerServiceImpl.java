package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.lti.entity.Customer;
import com.lti.exception.CustomerServiceException;
import com.lti.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired 
	private CustomerRepository customerRepo;
	
	@Override
	public void register(Customer customer){
		if(!customerRepo.isRegisteredCustomer(customer.getEmail())) {
			customerRepo.save(customer);
		}
		else
			throw new CustomerServiceException("Customer Already Present");
	}
	
	@Override
	public Customer login(String email, String password) {
		try {
			if(!customerRepo.isRegisteredCustomer(email))
				throw new CustomerServiceException("Customer not registered");
			int id= (int) customerRepo.fetchByEmailPassword(email, password);
			Customer customer = customerRepo.fetchById(id);
			return customer;
		}
		catch(EmptyResultDataAccessException e) {
			throw new CustomerServiceException("Incorrect email or password");
		}
	}
}
